//
//  app2Tests.swift
//  app2Tests
//
//  Created by Daniel  Ricaño on 27/10/25.
//

import Testing
@testable import app2

struct app2Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}

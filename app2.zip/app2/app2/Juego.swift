//
//  Juego.swift
//  app2
//
//  Created by Daniel Ricaño on 27/10/25.
//  Versión corregida y mejorada
//

import SwiftUI
import Combine

fileprivate enum Direction {
    case up, down, left, right
}

fileprivate struct GridPoint: Equatable, Hashable {
    var x: Int
    var y: Int
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(x)
        hasher.combine(y)
    }
}

struct JuegoView: View {
    // Configuración del tablero
    private let columns = 16
    private let rows = 24
    private let tick: TimeInterval = 0.15
    
    // Estado del juego
    @State private var hoja: [GridPoint] = [GridPoint(x: 8, y: 12)]
    @State private var direction: Direction = .right
    @State private var pendingDirection: Direction? = nil
    @State private var gotas: [GridPoint] = []
    @State private var score: Int = 0
    @State private var isAlive = true
    @State private var isPaused = false
    @State private var isViewActive = false
    @State private var animateScore = false
    @State private var particulas: [Particula] = []
    @State private var nivel: Int = 1
    @State private var tiempoRestante: Int = 60
    @State private var mostrarInstrucciones = true
    
    // Fondo estático (puntos) para evitar que cambien en cada render
    @State private var backgroundDots: [CGPoint] = []
    
    // Timers - usar AnyCancellable
    fileprivate var gameTimer: Timer.TimerPublisher {
        Timer.publish(every: tick, on: .main, in: .common)
    }
    fileprivate var tiempoTimer: Timer.TimerPublisher {
        Timer.publish(every: 1, on: .main, in: .common)
    }
    @State private var gameTimerCancellable: AnyCancellable?
    @State private var tiempoTimerCancellable: AnyCancellable?

    var body: some View {
        ZStack {
            // Fondo de juego con gradiente natural
            LinearGradient(
                colors: [Color(.systemGreen).opacity(0.1), Color(.systemTeal).opacity(0.2)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            
            VStack(spacing: 16) {
                header
                
                GeometryReader { geo in
                    let cellSize = min(geo.size.width / CGFloat(columns), geo.size.height / CGFloat(rows))
                    let boardWidth = cellSize * CGFloat(columns)
                    let boardHeight = cellSize * CGFloat(rows)
                    
                    ZStack {
                        // Fondo del tablero con textura de hojas
                        RoundedRectangle(cornerRadius: 20)
                            .fill(
                                LinearGradient(
                                    colors: [.green.opacity(0.3), .teal.opacity(0.2)],
                                    startPoint: .topLeading,
                                    endPoint: .bottomTrailing
                                )
                            )
                            .overlay(
                                RoundedRectangle(cornerRadius: 20)
                                    .stroke(.green.opacity(0.4), lineWidth: 3)
                            )
                            .frame(width: boardWidth, height: boardHeight)
                            .shadow(color: .black.opacity(0.1), radius: 8, x: 0, y: 4)
                        
                        // Patrón de fondo sutil (posiciones ya calculadas)
                        ForEach(backgroundDots.indices, id: \.self) { i in
                            Circle()
                                .fill(Color.green.opacity(0.05))
                                .frame(width: cellSize * 0.3, height: cellSize * 0.3)
                                .position(x: min(max(backgroundDots[i].x, 0), boardWidth),
                                          y: min(max(backgroundDots[i].y, 0), boardHeight))
                                .allowsHitTesting(false)
                        }
                        
                        // Gotas de agua
                        ForEach(Array(gotas.enumerated()), id: \.offset) { index, gota in
                            ZStack {
                                // Efecto de agua con múltiples círculos
                                Circle()
                                    .fill(Color.blue.opacity(0.8))
                                    .frame(width: cellSize * 0.6, height: cellSize * 0.6)
                                
                                Circle()
                                    .fill(Color.cyan.opacity(0.6))
                                    .frame(width: cellSize * 0.4, height: cellSize * 0.4)
                                
                                Circle()
                                    .fill(Color.white.opacity(0.4))
                                    .frame(width: cellSize * 0.2, height: cellSize * 0.2)
                                
                                // Brillo
                                Circle()
                                    .fill(Color.white.opacity(0.3))
                                    .frame(width: cellSize * 0.1, height: cellSize * 0.1)
                                    .offset(x: -cellSize * 0.15, y: -cellSize * 0.15)
                            }
                            .position(position(for: gota, cell: cellSize))
                            .scaleEffect(animateScore ? 1.15 : 1.0)
                            .animation(.easeInOut(duration: 0.45), value: animateScore)
                        }
                        
                        // Hoja (serpiente mejorada)
                        ForEach(Array(hoja.enumerated()), id: \.offset) { idx, segment in
                            let isHead = idx == 0
                            let isTail = idx == hoja.count - 1
                            
                            ZStack {
                                // Cuerpo de la hoja
                                if isHead {
                                    // Cabeza - una hoja linda
                                    Image(systemName: "leaf.fill")
                                        .font(.system(size: cellSize * 1.0))
                                        .foregroundStyle(
                                            LinearGradient(
                                                colors: [.green, .mint],
                                                startPoint: .topLeading,
                                                endPoint: .bottomTrailing
                                            )
                                        )
                                        .rotationEffect(rotationForHead())
                                } else if isTail {
                                    // Cola - pequeña y redondeada
                                    Circle()
                                        .fill(
                                            LinearGradient(
                                                colors: [.mint, .green],
                                                startPoint: .topLeading,
                                                endPoint: .bottomTrailing
                                            )
                                        )
                                        .frame(width: cellSize * 0.6, height: cellSize * 0.6)
                                } else {
                                    // Segmento del cuerpo
                                    RoundedRectangle(cornerRadius: cellSize * 0.16)
                                        .fill(
                                            LinearGradient(
                                                colors: [.green, .mint],
                                                startPoint: .topLeading,
                                                endPoint: .bottomTrailing
                                            )
                                        )
                                        .frame(width: cellSize * 0.78, height: cellSize * 0.78)
                                }
                            }
                            .position(position(for: segment, cell: cellSize))
                            .shadow(color: .black.opacity(0.2), radius: 2, x: 0, y: 1)
                        }
                        
                        // Partículas de efecto
                        ForEach(particulas) { particula in
                            Circle()
                                .fill(particula.color)
                                .frame(width: particula.size, height: particula.size)
                                .position(particula.position)
                                .opacity(particula.opacity)
                                .allowsHitTesting(false)
                        }
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .contentShape(Rectangle())
                    .gesture(swipeGestures())
                    .onAppear {
                        // Inicializar backgroundDots en función del tamaño real del tablero
                        if backgroundDots.isEmpty {
                            backgroundDots = generateBackgroundDots(count: (columns * rows) / 4, boardSize: CGSize(width: boardWidth, height: boardHeight))
                        }
                    }
                }
                
                // Nuevo sistema de controles circular
                controlesCirculares
            }
            .padding()
            
            // Overlay de instrucciones
            if mostrarInstrucciones {
                InstruccionesView(mostrarInstrucciones: $mostrarInstrucciones)
            }
            
            // Overlay de game over
            if !isAlive {
                GameOverView(score: score, nivel: nivel, reset: reset)
            }
        }
        .onAppear {
            isViewActive = true
            animateScore = false
            // Inicial spawn
            hoja = [GridPoint(x: columns/2, y: rows/2)]
            spawnGotas(cantidad: 3)
            
            // Configurar timers (crear y mantener cancellables)
            // Cancelar si existían (por seguridad)
            gameTimerCancellable?.cancel()
            tiempoTimerCancellable?.cancel()
            
            // game loop
            gameTimerCancellable = gameTimer.autoconnect()
                .sink { _ in
                    guard isAlive, !isPaused, isViewActive else { return }
                    step()
                }
            
            // tiempo restante
            tiempoTimerCancellable = tiempoTimer.autoconnect()
                .sink { _ in
                    guard isAlive, !isPaused, isViewActive else { return }
                    if tiempoRestante > 0 {
                        tiempoRestante -= 1
                    } else {
                        subirNivel()
                    }
                }
        }
        .onDisappear {
            isViewActive = false
            gameTimerCancellable?.cancel()
            tiempoTimerCancellable?.cancel()
        }
    }
    
    // MARK: - Header mejorado
    private var header: some View {
        VStack(spacing: 12) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Hoja Acuática")
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundStyle(.green)
                    
                    HStack {
                        Label("\(score)", systemImage: "drop.fill")
                            .foregroundStyle(.blue)
                            .scaleEffect(animateScore ? 1.2 : 1.0)
                            .animation(.spring(response: 0.3, dampingFraction: 0.5), value: animateScore)
                        
                        Text("•")
                            .foregroundStyle(.secondary)
                        
                        Label("Nivel \(nivel)", systemImage: "leaf.fill")
                            .foregroundStyle(.green)
                        
                        Text("•")
                            .foregroundStyle(.secondary)
                        
                        Label("\(tiempoRestante)s", systemImage: "clock.fill")
                            .foregroundStyle(tiempoRestante <= 10 ? .red : .orange)
                    }
                    .font(.subheadline)
                }
                
                Spacer()
                
                Button(action: { isPaused.toggle() }) {
                    Image(systemName: isPaused ? "play.circle.fill" : "pause.circle.fill")
                        .font(.title2)
                        .foregroundStyle(isPaused ? .green : .blue)
                }
            }
            
            // Barra de progreso del nivel
            ProgressView(value: min(Double(score), Double(nivel * 5)), total: Double(nivel * 5))
                .progressViewStyle(LinearProgressViewStyle(tint: .blue))
                .scaleEffect(x: 1, y: 1.5, anchor: .center)
        }
    }
    
    // MARK: - Nuevo sistema de controles circulares
    private var controlesCirculares: some View {
        ZStack {
            // Círculo base
            Circle()
                .fill(.ultraThinMaterial)
                .frame(width: 160, height: 160)
                .shadow(color: .black.opacity(0.1), radius: 8, x: 0, y: 4)
            
            // Controles direccionales
            VStack(spacing: 8) {
                ControlButton(direction: .up, action: { queueDirection(.up) })
                
                HStack(spacing: 8) {
                    ControlButton(direction: .left, action: { queueDirection(.left) })
                    
                    // Centro táctil para movimiento continuo
                    Circle()
                        .fill(Color.blue.opacity(0.2))
                        .frame(width: 50, height: 50)
                        .overlay(
                            Circle()
                                .stroke(Color.blue.opacity(0.4), lineWidth: 2)
                        )
                        .gesture(
                            DragGesture(minimumDistance: 0)
                                .onChanged { value in
                                    let angle = atan2(value.location.y - 25, value.location.x - 25)
                                    let distance = hypot(value.location.x - 25, value.location.y - 25)
                                    
                                    if distance > 15 { // Solo si se mueve fuera del centro
                                        if abs(angle) < .pi/4 {
                                            queueDirection(.right)
                                        } else if abs(angle) > (3)*(.pi)/4 {
                                            queueDirection(.left)
                                        } else if angle > 0 {
                                            queueDirection(.down)
                                        } else {
                                            queueDirection(.up)
                                        }
                                    }
                                }
                        )
                    
                    ControlButton(direction: .right, action: { queueDirection(.right) })
                }
                
                ControlButton(direction: .down, action: { queueDirection(.down) })
            }
        }
        .padding(.top, 20)
    }
    
    // MARK: - Lógica del juego mejorada
    private func step() {
        if let next = pendingDirection, canChange(to: next) {
            direction = next
        }
        pendingDirection = nil
        
        var newHead = hoja.first!
        switch direction {
        case .up: newHead.y -= 1
        case .down: newHead.y += 1
        case .left: newHead.x -= 1
        case .right: newHead.x += 1
        }
        
        // Colisión con bordes (teletransporta)
        if newHead.x < 0 { newHead.x = columns - 1 }
        else if newHead.x >= columns { newHead.x = 0 }
        if newHead.y < 0 { newHead.y = rows - 1 }
        else if newHead.y >= rows { newHead.y = 0 }
        
        // Colisión con cuerpo
        if hoja.contains(newHead) {
            isAlive = false
            return
        }
        
        hoja.insert(newHead, at: 0)
        
        // Verificar colisión con gotas
        if let gotaIndex = gotas.firstIndex(of: newHead) {
            score += 1
            // crear partículas usando cell aproximado (se pasa como cellSize absoluto si quieres precisión)
            crearParticulas(en: newHead, approximateCell: 24)
            gotas.remove(at: gotaIndex)
            
            // Efecto visual
            withAnimation(.spring(response: 0.3, dampingFraction: 0.6)) {
                animateScore = true
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) {
                animateScore = false
            }
            
            // Spawn nueva gota con límite de intentos
            if gotas.count < nivel + 2 {
                spawnGotas(cantidad: 1)
            }
        } else {
            _ = hoja.popLast()
        }
        
        // Actualizar partículas
        particulas = particulas.filter { $0.life > 0 }
        for i in particulas.indices {
            particulas[i].position.x += particulas[i].velocity.x
            particulas[i].position.y += particulas[i].velocity.y
            particulas[i].life -= 1
            particulas[i].opacity = Double(particulas[i].life) / 40.0
        }
    }
    
    private func spawnGotas(cantidad: Int) {
        let maxAttempts = 200
        var attempts = 0
        for _ in 0..<cantidad {
            var free: GridPoint
            repeat {
                free = GridPoint(x: Int.random(in: 0..<columns), y: Int.random(in: 0..<rows))
                attempts += 1
                if attempts > maxAttempts { break }
            } while hoja.contains(free) || gotas.contains(free)
            if attempts > maxAttempts { break }
            // Sólo agrega si no está tomado
            if !hoja.contains(free) && !gotas.contains(free) {
                gotas.append(free)
            }
        }
    }
    
    private func crearParticulas(en point: GridPoint, approximateCell: CGFloat) {
        // approximateCell: tamaño aproximado del "cell" en puntos (para posicionar partículas cerca de la celda)
        for _ in 0..<8 {
            let center = position(for: point, cell: approximateCell)
            let particula = Particula(
                position: CGPoint(x: center.x + CGFloat.random(in: -10...10), y: center.y + CGFloat.random(in: -10...10)),
                color: [Color.blue, Color.cyan, Color.white].randomElement() ?? .blue,
                size: CGFloat.random(in: 3...7),
                velocity: CGPoint(x: CGFloat.random(in: -1.5...1.5), y: CGFloat.random(in: -1.5...1.5)),
                life: Int.random(in: 20...40)
            )
            particulas.append(particula)
        }
    }
    
    private func subirNivel() {
        nivel += 1
        tiempoRestante = 60 + (nivel * 10) // Más tiempo por nivel
        score = 0
        hoja = [GridPoint(x: columns/2, y: rows/2)]
        direction = .right
        gotas.removeAll()
        spawnGotas(cantidad: nivel + 2)
        
        // Efecto visual de nuevo nivel
        withAnimation(.spring()) {
            animateScore = true
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            animateScore = false
        }
    }
    
    private func canChange(to newDir: Direction) -> Bool {
        switch (direction, newDir) {
        case (.up, .down), (.down, .up), (.left, .right), (.right, .left): return false
        default: return true
        }
    }
    
    private func queueDirection(_ newDir: Direction) {
        if canChange(to: newDir) { pendingDirection = newDir }
    }
    
    private func rotationForHead() -> Angle {
        switch direction {
        case .up: return .degrees(0)
        case .down: return .degrees(180)
        case .left: return .degrees(-90)
        case .right: return .degrees(90)
        }
    }
    
    private func swipeGestures() -> some Gesture {
        DragGesture(minimumDistance: 10)
            .onEnded { value in
                let dx = value.translation.width
                let dy = value.translation.height
                if abs(dx) > abs(dy) {
                    queueDirection(dx > 0 ? .right : .left)
                } else {
                    queueDirection(dy > 0 ? .down : .up)
                }
            }
    }
    
    private func position(for point: GridPoint, cell: CGFloat) -> CGPoint {
        // calcula el centro de la celda en coordenadas locales donde se dibuja el tablero
        // Si 'cell' es pequeño (approx), la posición será aproximada; ideal pasar cellSize real si está disponible.
        let x = (CGFloat(point.x) + 0.5) * cell
        let y = (CGFloat(point.y) + 0.5) * cell
        return CGPoint(x: x, y: y)
    }
    
    private func reset() {
        hoja = [GridPoint(x: columns/2, y: rows/2)]
        direction = .right
        pendingDirection = nil
        score = 0
        nivel = 1
        tiempoRestante = 60
        isAlive = true
        isPaused = false
        gotas.removeAll()
        particulas.removeAll()
        spawnGotas(cantidad: 3)
        
        // Reiniciar timers de forma segura
        gameTimerCancellable?.cancel()
        tiempoTimerCancellable?.cancel()
        
        gameTimerCancellable = gameTimer.autoconnect().sink { _ in
            guard self.isAlive, !self.isPaused, self.isViewActive else { return }
            self.step()
        }
        
        tiempoTimerCancellable = tiempoTimer.autoconnect().sink { _ in
            guard self.isAlive, !self.isPaused, self.isViewActive else { return }
            if self.tiempoRestante > 0 {
                self.tiempoRestante -= 1
            } else {
                self.subirNivel()
            }
        }
    }
    
    // Genera posiciones aleatorias (determinísticas por sesión) para el fondo
    private func generateBackgroundDots(count: Int, boardSize: CGSize) -> [CGPoint] {
        var dots: [CGPoint] = []
        let rng = SystemRandomNumberGenerator()
        for _ in 0..<count {
            let x = CGFloat.random(in: 0...boardSize.width)
            let y = CGFloat.random(in: 0...boardSize.height)
            dots.append(CGPoint(x: x, y: y))
        }
        return dots
    }
}

// MARK: - Componentes auxiliares

struct ControlButton: View {
    fileprivate let direction: Direction
    let action: () -> Void
    
    var icon: String {
        switch direction {
        case .up: return "chevron.up"
        case .down: return "chevron.down"
        case .left: return "chevron.left"
        case .right: return "chevron.right"
        }
    }
    
    var body: some View {
        Button(action: action) {
            Image(systemName: icon)
                .font(.system(size: 20, weight: .bold))
                .foregroundColor(.white)
                .frame(width: 44, height: 44)
                .background(
                    Circle()
                        .fill(Color.blue.gradient)
                        .shadow(color: .black.opacity(0.2), radius: 3, x: 0, y: 2)
                )
        }
    }
}

struct Particula: Identifiable {
    let id = UUID()
    var position: CGPoint
    let color: Color
    let size: CGFloat
    let velocity: CGPoint
    var life: Int
    var opacity: Double = 1.0
}

struct InstruccionesView: View {
    @Binding var mostrarInstrucciones: Bool
    
    var body: some View {
        ZStack {
            Color.black.opacity(0.8)
                .ignoresSafeArea()
            
            VStack(spacing: 20) {
                Text("🌿 Hoja Acuática")
                    .font(.title)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                
                VStack(alignment: .leading, spacing: 12) {
                    InstruccionRow(icon: "leaf.fill", text: "Controla la hoja para recolectar gotas de agua", color: .green)
                    InstruccionRow(icon: "drop.fill", text: "Cada gota hace crecer tu hoja", color: .blue)
                    InstruccionRow(icon: "clock.fill", text: "Completa el nivel antes de que se acabe el tiempo", color: .orange)
                    InstruccionRow(icon: "gamecontroller.fill", text: "Usa los controles táctiles o desliza el dedo", color: .purple)
                }
                
                Button("¡Jugar!") {
                    withAnimation(.spring()) {
                        mostrarInstrucciones = false
                    }
                }
                .font(.title2)
                .fontWeight(.semibold)
                .foregroundColor(.white)
                .padding(.horizontal, 40)
                .padding(.vertical, 12)
                .background(Color.green.gradient)
                .clipShape(RoundedRectangle(cornerRadius: 16))
                .shadow(color: .black.opacity(0.3), radius: 8, x: 0, y: 4)
            }
            .padding(30)
            .background(
                RoundedRectangle(cornerRadius: 25)
                    .fill(.ultraThinMaterial)
                    .shadow(color: .black.opacity(0.3), radius: 20, x: 0, y: 10)
            )
            .padding(40)
        }
    }
}

struct InstruccionRow: View {
    let icon: String
    let text: String
    let color: Color
    
    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .font(.title3)
                .foregroundColor(color)
                .frame(width: 24)
            
            Text(text)
                .foregroundColor(.white)
                .font(.body)
            
            Spacer()
        }
    }
}

struct GameOverView: View {
    let score: Int
    let nivel: Int
    let reset: () -> Void
    
    var body: some View {
        ZStack {
            Color.black.opacity(0.8)
                .ignoresSafeArea()
            
            VStack(spacing: 20) {
                Text("🌧️ Game Over")
                    .font(.title)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                
                VStack(spacing: 12) {
                    Text("Puntuación Final")
                        .font(.headline)
                        .foregroundColor(.white.opacity(0.8))
                    
                    Text("\(score)")
                        .font(.system(size: 48, weight: .bold, design: .rounded))
                        .foregroundColor(.blue)
                    
                    Text("Nivel alcanzado: \(nivel)")
                        .font(.title3)
                        .foregroundColor(.green)
                }
                
                Button("Jugar de Nuevo") {
                    reset()
                }
                .font(.title2)
                .fontWeight(.semibold)
                .foregroundColor(.white)
                .padding(.horizontal, 40)
                .padding(.vertical, 12)
                .background(Color.blue.gradient)
                .clipShape(RoundedRectangle(cornerRadius: 16))
                .shadow(color: .black.opacity(0.3), radius: 8, x: 0, y: 4)
            }
            .padding(30)
            .background(
                RoundedRectangle(cornerRadius: 25)
                    .fill(.ultraThinMaterial)
                    .shadow(color: .black.opacity(0.3), radius: 20, x: 0, y: 10)
            )
            .padding(40)
        }
    }
}

#Preview {
    JuegoView()
}

//
//  InicioView.swift
//  app2
//
//  Created by Daniel Ricaño on 27/10/25.
//

import SwiftUI

struct InicioView: View {
    @State private var showMenu = false
    @State private var indiceDato = 0
    @State private var animateCard = false
    @State private var showWarning = false
    @EnvironmentObject var consumoStore: ConsumoStore

    let datosCuriosos = [
        "💧 Cerrar la llave al cepillarte ahorra hasta 30L diarios",
        "🌍 Solo el 1% del agua mundial está disponible para consumo",
        "🚿 Duchas de 5 minutos usan aproximadamente 60L de agua",
        "🌱 Regar plantas al atardecer reduce la evaporación",
        "🧼 Lavar platos con tapón abierto gasta 12L por minuto",
        "🚗 Lavar auto con cubeta ahorra hasta 300L vs manguera",
        "🔧 Una fuga pequeña puede desperdiciar 100L al día"
    ]
    
    // Límite de consumo diario
    private let limiteConsumo: Double = 200.0
    
    // Computed property para determinar el color del consumo
    private var colorConsumo: Color {
        consumoStore.totalHoy() > limiteConsumo ? .red : .blue
    }
    
    // Computed property para el mensaje del consumo
    private var mensajeConsumo: String {
        if consumoStore.totalHoy() > limiteConsumo {
            return "¡Alerta! Excedes el límite 🚨"
        } else if consumoStore.totalHoy() > limiteConsumo * 0.8 {
            return "¡Cuidado! Estás cerca del límite ⚠️"
        } else {
            return "¡Buen trabajo! 💧"
        }
    }

    var body: some View {
        NavigationStack {
            ZStack(alignment: .topLeading) {
                // Fondo limpio y suave
                LinearGradient(
                    colors: [Color(.systemGray6), .white],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .ignoresSafeArea()
                
                // Contenido principal
                VStack(spacing: 0) {
                    // Header minimalista
                    HStack {
                        Button(action: {
                            withAnimation(.spring(response: 0.6, dampingFraction: 0.8)) {
                                showMenu.toggle()
                            }
                        }) {
                            Image(systemName: "line.horizontal.3")
                                .font(.title3)
                                .foregroundColor(.primary)
                                .padding(12)
                                .background(.ultraThinMaterial)
                                .clipShape(Circle())
                        }
                        
                        Spacer()
                        
                        VStack(spacing: 4) {
                            Text("Ely Sabe")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundStyle(.primary)
                            Text("Hoy")
                                .font(.caption2)
                                .foregroundStyle(.secondary)
                        }
                        
                        Spacer()
                        
                        // Espacio para balancear el diseño
                        Circle()
                            .fill(Color.clear)
                            .frame(width: 44, height: 44)
                    }
                    .padding(.horizontal)
                    .padding(.top, 8)
                    
                    ScrollView {
                        VStack(spacing: 24) {
                            // Tarjeta de consumo principal con alerta
                            VStack(spacing: 16) {
                                Text("Consumo de Hoy")
                                    .font(.headline)
                                    .foregroundStyle(.secondary)
                                
                                HStack(alignment: .lastTextBaseline, spacing: 8) {
                                    Text("\(String(format: "%.0f", consumoStore.totalHoy()))")
                                        .font(.system(size: 48, weight: .bold, design: .rounded))
                                        .foregroundStyle(colorConsumo)
                                        .scaleEffect(showWarning ? 1.1 : 1.0)
                                        .animation(
                                            .easeInOut(duration: 0.6)
                                            .repeatCount(showWarning ? 3 : 0, autoreverses: true),
                                            value: showWarning
                                        )
                                    
                                    Text("L")
                                        .font(.title2)
                                        .foregroundStyle(.secondary)
                                }
                                
                                Text(mensajeConsumo)
                                    .font(.caption)
                                    .fontWeight(.medium)
                                    .foregroundStyle(colorConsumo)
                                    .opacity(showWarning ? 1.0 : 0.8)
                            }
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 24)
                            .background(.white)
                            .clipShape(RoundedRectangle(cornerRadius: 20))
                            .shadow(color: .black.opacity(0.05), radius: 8, x: 0, y: 2)
                            .overlay(
                                RoundedRectangle(cornerRadius: 20)
                                    .stroke(colorConsumo.opacity(showWarning ? 0.3 : 0.1), lineWidth: 2)
                            )
                            .padding(.horizontal)
                            
                            // Indicador de progreso hacia el límite
                            if consumoStore.totalHoy() > 0 {
                                VStack(spacing: 12) {
                                    HStack {
                                        Text("Límite diario: \(Int(limiteConsumo))L")
                                            .font(.caption)
                                            .foregroundStyle(.secondary)
                                        Spacer()
                                        Text("\(Int((consumoStore.totalHoy() / limiteConsumo) * 100))%")
                                            .font(.caption)
                                            .fontWeight(.semibold)
                                            .foregroundStyle(colorConsumo)
                                    }
                                    
                                    ProgressView(value: consumoStore.totalHoy(), total: limiteConsumo)
                                        .progressViewStyle(LinearProgressViewStyle(tint: colorConsumo))
                                        .scaleEffect(x: 1, y: 1.5, anchor: .center)
                                }
                                .padding(.horizontal)
                            }
                            
                            // Datos curiosos con cambio automático
                            VStack(spacing: 16) {
                                HStack {
                                    Text("Sabías que...")
                                        .font(.title3)
                                        .fontWeight(.semibold)
                                        .foregroundStyle(.primary)
                                    Spacer()
                                    
                                    Image(systemName: "lightbulb.fill")
                                        .foregroundColor(.orange)
                                        .font(.caption)
                                }
                                
                                VStack(spacing: 0) {
                                    Text(datosCuriosos[indiceDato])
                                        .font(.body)
                                        .multilineTextAlignment(.center)
                                        .padding()
                                        .frame(maxWidth: .infinity)
                                        .background(.white)
                                        .clipShape(RoundedRectangle(cornerRadius: 16))
                                        .shadow(color: .black.opacity(0.05), radius: 4, x: 0, y: 2)
                                        .scaleEffect(animateCard ? 1.02 : 1.0)
                                        .animation(.easeInOut(duration: 0.3), value: animateCard)
                                    
                                    HStack {
                                        Text("Siguiente dato en:")
                                            .font(.caption2)
                                            .foregroundStyle(.secondary)
                                        
                                        Text("\(5) seg")
                                            .font(.caption2)
                                            .fontWeight(.medium)
                                            .foregroundStyle(.blue)
                                    }
                                    .padding(.top, 8)
                                }
                            }
                            .padding(.horizontal)
                            
                            // Acciones rápidas
                            LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 2), spacing: 16) {
                                NavigationLink(destination: Actividades()) {
                                    QuickActionCard(
                                        title: "Registrar",
                                        subtitle: "Actividad",
                                        icon: "plus.circle.fill",
                                        color: .blue
                                    )
                                }
                                
                                NavigationLink(destination: ConsumosView()) {
                                    QuickActionCard(
                                        title: "Ver",
                                        subtitle: "Estadísticas",
                                        icon: "chart.bar.fill",
                                        color: .green
                                    )
                                }
                                
                                NavigationLink(destination: PantallaDosView()) {
                                    QuickActionCard(
                                        title: "Chat con",
                                        subtitle: "Ely 🐘",
                                        icon: "message.fill",
                                        color: .cyan
                                    )
                                }
                                
                                NavigationLink(destination: JuegoView()) {
                                    QuickActionCard(
                                        title: "Juego",
                                        subtitle: "Hoja Acuática",
                                        icon: "gamecontroller.fill",
                                        color: .orange
                                    )
                                }
                            }
                            .padding(.horizontal)
                        }
                        .padding(.vertical)
                    }
                }
                .opacity(showMenu ? 0.3 : 1.0)
                .scaleEffect(showMenu ? 0.95 : 1.0)
                .animation(.spring(response: 0.5, dampingFraction: 0.8), value: showMenu)
                .disabled(showMenu)
                
                // Menú lateral
                if showMenu {
                    Color.black.opacity(0.15)
                        .ignoresSafeArea()
                        .onTapGesture {
                            withAnimation(.spring(response: 0.5, dampingFraction: 0.8)) {
                                showMenu = false
                            }
                        }
                    
                    VStack(alignment: .leading, spacing: 0) {
                        // Header del menú
                        VStack(alignment: .leading, spacing: 16) {
                            Circle()
                                .fill(
                                    LinearGradient(
                                        colors: [.blue, .cyan],
                                        startPoint: .topLeading,
                                        endPoint: .bottomTrailing
                                    )
                                )
                                .frame(width: 60, height: 60)
                                .overlay(
                                    Image("ely")
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: 200, height: 200)                                        .font(.title3)
                                        .foregroundColor(.white)
                                )
                            
                            VStack(alignment: .leading, spacing: 4) {
                                Text("Ely Sabe")
                                    .font(.title2)
                                    .fontWeight(.bold)
                                    .foregroundStyle(.primary)
                                Text("Cuida cada gota")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                        }
                        .padding(.horizontal, 24)
                        .padding(.top, 60)
                        .padding(.bottom, 32)
                        
                        Divider()
                            .padding(.horizontal, 16)
                        
                        // Opciones del menú
                        VStack(alignment: .leading, spacing: 0) {
                            MenuRow(
                                title: "Mi Perfil",
                                icon: "person.circle.fill",
                                destination: PerfilView()
                            )
                            
                            MenuRow(
                                title: "Mis Consumos",
                                icon: "chart.bar.fill",
                                destination: ConsumosView()
                            )
                            
                            MenuRow(
                                title: "Chat con Ely",
                                icon: "message.fill",
                                destination: PantallaDosView()
                            )
                            
                            MenuRow(
                                title: "Juego",
                                icon: "gamecontroller.fill",
                                destination: JuegoView()
                            )
                        }
                        .padding(.vertical, 16)
                        
                        Spacer()
                        
                        // Footer
                        VStack(alignment: .leading, spacing: 8) {
                            Divider()
                                .padding(.horizontal, 16)
                            
                            Text("Juntos por un futuro sostenible")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                                .padding(.horizontal, 24)
                                .padding(.bottom, 20)
                        }
                    }
                    .frame(maxWidth: 280)
                    .background(.regularMaterial)
                    .clipShape(RoundedRectangle(cornerRadius: 16))
                    .shadow(color: .black.opacity(0.1), radius: 10, x: 2, y: 2)
                    .transition(.move(edge: .leading).combined(with: .opacity))
                }
            }
        }
        .onAppear {
            // Iniciar el cambio automático de datos curiosos
            startAutoChangeDatosCuriosos()
            // Verificar si hay advertencia al aparecer
            checkWarning()
        }
        .onChange(of: consumoStore.totalHoy()) { _ in
            // Verificar advertencia cuando cambie el consumo
            checkWarning()
        }
    }
    
    // MARK: - Funciones auxiliares
    
    // Función para iniciar el cambio automático de datos curiosos
    private func startAutoChangeDatosCuriosos() {
        Timer.scheduledTimer(withTimeInterval: 5.0, repeats: true) { _ in
            withAnimation(.easeInOut(duration: 0.2)) {
                animateCard = true
            }
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                var nuevo: Int
                repeat {
                    nuevo = Int.random(in: 0..<datosCuriosos.count)
                } while nuevo == indiceDato
                indiceDato = nuevo
            }
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                withAnimation(.easeInOut(duration: 0.2)) {
                    animateCard = false
                }
            }
        }
    }
    
    // Función para verificar y activar la advertencia
    private func checkWarning() {
        let excedeLimite = consumoStore.totalHoy() > limiteConsumo
        
        if excedeLimite && !showWarning {
            // Activar la animación de advertencia
            withAnimation(.easeInOut(duration: 0.5)) {
                showWarning = true
            }
            
            // Haptic feedback para alerta
            let generator = UINotificationFeedbackGenerator()
            generator.notificationOccurred(.warning)
            
            // Parpadear 3 veces
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                withAnimation(.easeInOut(duration: 0.5)) {
                    showWarning = false
                }
            }
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                withAnimation(.easeInOut(duration: 0.5)) {
                    showWarning = true
                }
            }
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
                withAnimation(.easeInOut(duration: 0.5)) {
                    showWarning = false
                }
            }
        } else if !excedeLimite {
            showWarning = false
        }
    }
}

// MARK: - Componentes

struct QuickActionCard: View {
    let title: String
    let subtitle: String
    let icon: String
    let color: Color
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Image(systemName: icon)
                .font(.title2)
                .foregroundColor(color)
            
            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.headline)
                    .foregroundStyle(.primary)
                Text(subtitle)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            
            Spacer()
        }
        .frame(height: 100)
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding()
        .background(.white)
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .shadow(color: .black.opacity(0.05), radius: 8, x: 0, y: 2)
    }
}

struct MenuRow<Destination: View>: View {
    let title: String
    let icon: String
    let destination: Destination
    
    var body: some View {
        NavigationLink(destination: destination) {
            HStack(spacing: 16) {
                Image(systemName: icon)
                    .font(.body)
                    .foregroundColor(.blue)
                    .frame(width: 24)
                
                Text(title)
                    .font(.body)
                    .foregroundStyle(.primary)
                
                Spacer()
                
                Image(systemName: "chevron.right")
                    .font(.caption)
                    .foregroundStyle(.tertiary)
            }
            .padding(.horizontal, 24)
            .padding(.vertical, 12)
            .contentShape(Rectangle())
        }
        .buttonStyle(PlainButtonStyle())
    }
}

#Preview {
    InicioView()
        .environmentObject(ConsumoStore())
}

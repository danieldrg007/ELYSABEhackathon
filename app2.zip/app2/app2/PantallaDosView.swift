import SwiftUI
import AVFoundation

// MARK: - Modelo de mensaje (con Equatable para la animación)
struct Mensaje: Identifiable, Equatable {
    let id = UUID()
    let texto: String
    let esUsuario: Bool
}

// MARK: - Modelo de conocimiento de Ely
struct ElyModel {
    static func respuesta(para pregunta: String) -> String {
        let texto = pregunta.lowercased()
        
        let temasDisponibles = "**Consumo Doméstico**, **Huella Hídrica** (alimentos), y **Crisis Global** (escasez, cambio climático)."

        // --- 1. Respuestas de Despedida ---
        if texto.contains("adiós") || texto.contains("bye") || texto.contains("chao") || texto.contains("hasta luego") {
             return "¡Adiós! Recuerda que cuidar el agua es responsabilidad de todos. ¡Vuelve pronto si tienes más preguntas! 💙"
        }
        
        // --- 2. Respuestas de Conversación ---
        
        if texto.contains("hola") {
            return "¡Hola! Soy Ely 🐘💧. Podemos hablar sobre: \(temasDisponibles). ¿Qué te interesa hoy?"
        } else if texto.contains("gracias") {
            return "¡De nada! Me alegra poder ayudar 💙 Recuerda: cada acción cuenta."
        }
        
        // --- 3. Detección de Consumo Doméstico (CORREGIDO Y PRIORIZADO) ---
        
        // 💧 GASTO PROMEDIO: Persona/Familia/Casa (AHORA MÁS ROBUSTO)
        if texto.contains("consumo") && (texto.contains("casa") || texto.contains("hogar") || texto.contains("persona")) {
            return "El consumo promedio de agua en una casa es de **250 a 350 litros por persona al día**. ¡Es un buen punto de partida para buscar reducir tu gasto! 🏡💧"
        } else if texto.contains("cuánto gasta") && (texto.contains("persona") || texto.contains("familia")) {
            return "El consumo promedio de agua en una casa es de **250 a 350 litros por persona al día**. ¡Es un buen punto de partida para buscar reducir tu gasto! 🏡💧"
        }
        
        // 💧 GASTO ESPECÍFICO: Lavadora
        else if texto.contains("lavadora") || (texto.contains("lavar") && texto.contains("ropa")) {
            return "Una lavadora eficiente usa unos **50-70 litros** por ciclo. Los modelos antiguos pueden gastar hasta 150 litros. ¡Llénala al máximo para ahorrar más! 🧺💧"
        }
        
        // 💧 GASTO ESPECÍFICO: Lavar Coche/Carro
        else if (texto.contains("lavar") && (texto.contains("coche") || texto.contains("carro"))) {
            return "Lavar el carro con una manguera puede gastar **hasta 500 litros** de agua. Si usas una cubeta, puedes reducir ese consumo a unos **50 litros**. ¡Usa la cubeta! 🚗 bucket"
        }
        
        // 💧 GASTO ESPECÍFICO: Lavar Platos/Vajilla
        else if (texto.contains("lavar") && (texto.contains("platos") || texto.contains("vajilla"))) {
            return "Si lavas los platos a mano con la llave abierta, puedes gastar hasta 100 litros. Un lavavajillas moderno y lleno gasta unos **10-15 litros**. 🍽️💦"
        }
        
        // 💧 GASTO ESPECÍFICO: Dientes
        else if texto.contains("dientes") || texto.contains("cepillar") {
            return "Si dejas la llave abierta mientras te cepillas los dientes, puedes gastar entre 5 y 15 litros de agua. ¡Usa un vaso! 🦷🚰"
        }
        
        // 💧 GASTO ESPECÍFICO: Ducha
        else if texto.contains("ducha") {
            return "Una ducha de 5 minutos usa unos 50 litros de agua. ¡Dúchate más rápido para ahorrar! 🚿♻️"
        }
        
        // 💧 GASTO ESPECÍFICO: Inodoro
        else if texto.contains("inodoro") || texto.contains("wc") || texto.contains("taza de baño") {
            return "Cada descarga de un inodoro tradicional puede usar entre 6 y 13 litros de agua. ¡Busca inodoros de bajo consumo! 🚽💙"
        }
        
        // 💧 RESPUESTA INTRODUCTORIA: Consumo Doméstico (si solo preguntan por el tema)
        else if texto.contains("consumo doméstico") || texto.contains("consumo en casa") {
            return "El consumo doméstico incluye el agua que usas en la ducha, el inodoro, la lavadora y al lavar platos. En promedio, gastamos de 250 a 350 litros por persona al día. ¿Quieres saber sobre la **ducha**, el **inodoro** o la **lavadora**?"
        }
        
        // --- 4. Detección de Huella Hídrica y Crisis Global ---
        
        // 💧 RESPUESTA DIRECTA: ¿Qué es la Huella Hídrica?
        else if texto.contains("qué es") && texto.contains("huella hídrica") {
            return "La **Huella Hídrica** es un indicador que mide el volumen total de agua dulce utilizada para producir un bien o servicio. Se compone de tres tipos de agua:\n* **Agua Verde:** Agua de lluvia almacenada en el suelo.\n* **Agua Azul:** Agua superficial o subterránea (ríos, lagos, acuíferos).\n* **Agua Gris:** Agua necesaria para diluir la contaminación generada por el proceso."
        }
        
        // 💧 RESPUESTA INTRODUCTORIA: Huella Hídrica
        else if texto.contains("huella hídrica") || (texto.contains("agua") && texto.contains("alimentos")) {
            return "La huella hídrica de los alimentos es muy alta; ¡el 86% de nuestra huella personal viene de lo que comemos! Pregúntame sobre la **carne**, el **aguacate** o el **arroz** para ver ejemplos."
        }
        
        // --- 5. Respuestas de Crisis Global ---
        
        else if texto.contains("escasez") && texto.contains("agua") {
            return "La **escasez de agua** ya afecta al 40% de la población mundial. Las consecuencias incluyen inseguridad alimentaria, riesgos sanitarios y la posible migración de millones de personas. 😥"
        } else if texto.contains("cambio climático") && texto.contains("agua") {
            return "El **cambio climático** agrava la crisis hídrica. Aumenta la intensidad de sequías e inundaciones, altera los patrones de lluvia y derrite glaciares, afectando la disponibilidad y calidad del agua dulce. 🌡️💧"
        } else if texto.contains("soluciones") && texto.contains("escasez") {
            return "Hay varias soluciones: mejorar la eficiencia del riego agrícola (el mayor consumidor), capturar agua de lluvia, reutilizar aguas residuales (como hace Singapur) y, por supuesto, reducir el consumo individual. 💡"
        } else if texto.contains("contaminación") && (texto.contains("agua") || texto.contains("ríos")) {
            return "El 80% de las aguas residuales en el mundo se vierten sin tratar. La contaminación por químicos, aceites y plásticos reduce la cantidad de agua apta para el consumo. ¡La calidad es tan importante como la cantidad! 🧪🗑️"
        }
        
        // --- 6. Respuestas de Huella Hídrica Específicas ---
        
        else if texto.contains("carne") && (texto.contains("agua") || texto.contains("gasta")) {
            return "Para producir 1 kg de carne de res se necesitan ¡más de **15,000 litros** de agua! Reducir el consumo es una gran ayuda al planeta. 🐄💧"
        } else if texto.contains("aguacate") && (texto.contains("agua") || texto.contains("gasta")) {
            return "Se estiman unos **2,000 litros** de agua para producir solo 1 kg de aguacates. Consúmelo con moderación. 🥑"
        } else if texto.contains("arroz") && (texto.contains("agua") || texto.contains("gasta")) {
            return "Producir 1 kg de arroz consume entre **3,000 y 5,000 litros** de agua. 🍚"
        }
        
        // --- 7. Validación de Temas (FALLBACK) ---
        
        let palabrasClaveRelevantes: [String] = ["agua", "consumo", "gasta", "cambio", "escasez", "huella", "persona", "familia"]
        let esRelevante = palabrasClaveRelevantes.contains { texto.contains($0) }
        
        if esRelevante {
            return sugerencias.randomElement() ?? "Cuidar el agua es tarea de todas las personas. 💧"
        } else {
             // Si el texto es completamente irrelevante (ej: "qué hora es")
            return "¡Soy Ely, un bot especializado en el agua y la sostenibilidad! 🐘💧 Mis temas principales son: \(temasDisponibles). ¿Sobre cuál te gustaría preguntar?"
        }
    }
    
    // --- 💡 Sugerencias ---
    static let sugerencias = [
        "Usa un vaso para enjuagarte los dientes y ahorra agua. 🦷💧",
        "Repara fugas tan pronto como las detectes. ¡Una fuga puede gastar miles de litros al mes! 🔧",
        "La carne de res gasta unos 15,000 litros por kg. Considera reducir su consumo. 💙",
        "Cierra la llave mientras te enjabonas las manos o lavas platos. 🙌💦",
        "Piensa en la huella hídrica cuando hagas tus compras. El consumo responsable ayuda mucho. 🛍️",
        "Evita tirar basura al drenaje. La contaminación del agua agrava la escasez. 🧪🗑️"
    ]
}

// MARK: - Vista principal del chat
struct PantallaDosView: View {
    @Environment(\.dismiss) var dismiss // Necesario para el botón de regreso
    
    @State private var mensajes: [Mensaje] = [
        Mensaje(texto: ElyModel.respuesta(para: "hola"), esUsuario: false)
    ]
    @State private var textoUsuario: String = ""
    private let sintetizador = AVSpeechSynthesizer()
    
    var body: some View {
        // En un entorno de desarrollo real, esta vista sería empujada a la NavigationStack,
        // lo que haría que el botón de regreso fuera automático.
        // Si la NavigationStack comienza aquí, se puede usar un botón manual para simular el regreso.
        NavigationStack {
            VStack {
                ScrollView {
                    ForEach(mensajes) { mensaje in
                        HStack(alignment: .bottom) {
                            if mensaje.esUsuario {
                                Spacer()
                                Text(mensaje.texto)
                                    .padding(10)
                                    .background(Color.blue.opacity(0.8))
                                    .foregroundColor(.white)
                                    .clipShape(RoundedRectangle(cornerRadius: 16))
                                    .padding(.horizontal)
                            } else {
                                HStack(alignment: .bottom, spacing: 8) {
                                    Image(systemName: "elephant")
                                        .font(.system(size: 26))
                                        .foregroundColor(.cyan)
                                    Text(mensaje.texto)
                                        .padding(10)
                                        .background(
                                            LinearGradient(
                                                colors: [.cyan.opacity(0.3), .blue.opacity(0.1)],
                                                startPoint: .topLeading,
                                                endPoint: .bottomTrailing
                                            )
                                        )
                                        .clipShape(RoundedRectangle(cornerRadius: 16))
                                }
                                .padding(.horizontal)
                                Spacer()
                            }
                        }
                        .transition(.opacity)
                        .animation(.easeInOut(duration: 0.3), value: mensajes)
                    }
                }
                .scrollDismissesKeyboard(.interactively)
                
                // Campo de texto y botón de envío
                HStack {
                    TextField("Escribe o pregunta algo a Ely...", text: $textoUsuario)
                        .textFieldStyle(.roundedBorder)
                        .padding(.leading)
                    
                    Button {
                        enviarMensaje()
                    } label: {
                        Image(systemName: "paperplane.fill")
                            .foregroundColor(.white)
                            .padding(10)
                            .background(.blue)
                            .clipShape(Circle())
                    }
                    .padding(.trailing)
                    .disabled(textoUsuario.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
                .padding(.bottom)
            }
            .navigationTitle("Chat con Ely 🐘")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                // Botón de regreso a la izquierda (Trailing)
                ToolbarItem(placement: .navigationBarLeading) {
                    Button {
                        // Acción para regresar a la vista anterior (simulado con dismiss)
                        dismiss()
                    } label: {
                        Image(systemName: "chevron.left")
                    }
                }
                
                // Botón de nuevo chat a la derecha (Trailing)
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Nuevo Chat") {
                        reiniciarChat()
                    }
                }
            }
            .background(Color(.systemBackground))
        }
    }
    
    // MARK: - Función para reiniciar la conversación
    func reiniciarChat() {
        mensajes = [
            Mensaje(texto: ElyModel.respuesta(para: "hola"), esUsuario: false)
        ]
        hablar(mensajes.first!.texto)
    }
    
    // MARK: - Función para enviar y hablar
    func enviarMensaje() {
        let texto = textoUsuario.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !texto.isEmpty else { return }
        
        mensajes.append(Mensaje(texto: texto, esUsuario: true))
        textoUsuario = ""
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
            let respuesta = ElyModel.respuesta(para: texto)
            mensajes.append(Mensaje(texto: respuesta, esUsuario: false))
            hablar(respuesta)
        }
    }
    
    // MARK: - Síntesis de voz de Ely
    func hablar(_ texto: String) {
        let utterance = AVSpeechUtterance(string: texto)
        utterance.voice = AVSpeechSynthesisVoice(language: "es-MX")
        utterance.rate = 0.47
        utterance.pitchMultiplier = 1.2
        sintetizador.speak(utterance)
    }
}

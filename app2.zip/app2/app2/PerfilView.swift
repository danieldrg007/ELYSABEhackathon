//
//  PerfilView.swift
//  app2
//
//  Created by Daniel Ricaño on 27/10/25.
//

import SwiftUI
import PhotosUI

struct PerfilView: View {
    @State private var selectedItem: PhotosPickerItem?
    @State private var selectedImageData: Data?
    @State private var selectedAvatar: String = ""
    @State private var userName: String = "Daniel Ricaño"
    @State private var userEmail: String = "usuario@ejemplo.com"
    @State private var isEditing: Bool = false
    @State private var showingImagePicker: Bool = false
    @State private var showingAvatarSelector: Bool = false
    
    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                // Header con foto de perfil
                VStack(spacing: 20) {
                    ZStack {
                        // Imagen de perfil (galería o avatar)
                        if let selectedImageData,
                           let uiImage = UIImage(data: selectedImageData) {
                            Image(uiImage: uiImage)
                                .resizable()
                                .scaledToFill()
                                .frame(width: 120, height: 120)
                                .clipShape(Circle())
                                .overlay(
                                    Circle()
                                        .stroke(Color.white, lineWidth: 4)
                                        .shadow(color: .black.opacity(0.1), radius: 4, x: 0, y: 2)
                                )
                        } else if !selectedAvatar.isEmpty {
                            Image(systemName: selectedAvatar)
                                .font(.system(size: 50))
                                .foregroundColor(.white)
                                .frame(width: 120, height: 120)
                                .background(
                                    LinearGradient(
                                        colors: [.blue, .cyan],
                                        startPoint: .topLeading,
                                        endPoint: .bottomTrailing
                                    )
                                )
                                .clipShape(Circle())
                                .overlay(
                                    Circle()
                                        .stroke(Color.white, lineWidth: 4)
                                        .shadow(color: .black.opacity(0.1), radius: 4, x: 0, y: 2)
                                )
                        } else {
                            Circle()
                                .fill(
                                    LinearGradient(
                                        colors: [.blue, .cyan],
                                        startPoint: .topLeading,
                                        endPoint: .bottomTrailing
                                    )
                                )
                                .frame(width: 120, height: 120)
                                .overlay(
                                    Image(systemName: "person.fill")
                                        .font(.system(size: 50))
                                        .foregroundColor(.white)
                                )
                        }
                        
                        // Botón de editar foto
                        VStack {
                            Spacer()
                            HStack {
                                Spacer()
                                Menu {
                                    Button {
                                        showingImagePicker = true
                                    } label: {
                                        Label("Desde Galería", systemImage: "photo")
                                    }
                                    
                                    Button {
                                        showingAvatarSelector = true
                                    } label: {
                                        Label("Avatar Predefinido", systemImage: "person.crop.circle")
                                    }
                                } label: {
                                    Image(systemName: "camera.circle.fill")
                                        .font(.title2)
                                        .foregroundColor(.white)
                                        .padding(6)
                                        .background(Color.blue)
                                        .clipShape(Circle())
                                        .shadow(color: .black.opacity(0.2), radius: 3, x: 0, y: 2)
                                }
                            }
                        }
                        .frame(width: 120, height: 120)
                    }
                    
                    VStack(spacing: 4) {
                        if isEditing {
                            TextField("Tu nombre", text: $userName)
                                .font(.title2)
                                .fontWeight(.semibold)
                                .multilineTextAlignment(.center)
                                .padding(.horizontal)
                                .background(Color(.systemGray6))
                                .clipShape(RoundedRectangle(cornerRadius: 8))
                        } else {
                            Text(userName)
                                .font(.title2)
                                .fontWeight(.semibold)
                                .foregroundStyle(.primary)
                        }
                        
                        Text(userEmail)
                            .font(.body)
                            .foregroundStyle(.secondary)
                    }
                    
                    // Botón de editar/guardar
                    Button {
                        withAnimation(.spring()) {
                            if isEditing {
                                // Guardar cambios
                                saveProfile()
                            }
                            isEditing.toggle()
                        }
                    } label: {
                        HStack {
                            Image(systemName: isEditing ? "checkmark.circle.fill" : "pencil.circle.fill")
                            Text(isEditing ? "Guardar Cambios" : "Editar Perfil")
                                .fontWeight(.semibold)
                        }
                        .foregroundColor(.white)
                        .padding(.horizontal, 24)
                        .padding(.vertical, 12)
                        .background(isEditing ? Color.green : Color.blue)
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                    }
                }
                .padding(.vertical, 32)
                .frame(maxWidth: .infinity)
                .background(
                    LinearGradient(
                        colors: [Color(.systemGray6), .white],
                        startPoint: .top,
                        endPoint: .bottom
                    )
                )
                
                // Información editable
                VStack(spacing: 20) {
                    VStack(alignment: .leading, spacing: 16) {
                        Text("Información Personal")
                            .font(.headline)
                            .foregroundStyle(.primary)
                            .padding(.horizontal)
                        
                        VStack(spacing: 16) {
                            VStack(alignment: .leading, spacing: 8) {
                                Text("Nombre")
                                    .font(.subheadline)
                                    .foregroundStyle(.secondary)
                                
                                if isEditing {
                                    TextField("Tu nombre", text: $userName)
                                        .padding()
                                        .background(Color(.systemBackground))
                                        .clipShape(RoundedRectangle(cornerRadius: 12))
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 12)
                                                .stroke(Color(.systemGray4), lineWidth: 1)
                                        )
                                } else {
                                    Text(userName)
                                        .padding()
                                        .frame(maxWidth: .infinity, alignment: .leading)
                                        .background(Color(.systemGray6))
                                        .clipShape(RoundedRectangle(cornerRadius: 12))
                                }
                            }
                            
                            VStack(alignment: .leading, spacing: 8) {
                                Text("Correo Electrónico")
                                    .font(.subheadline)
                                    .foregroundStyle(.secondary)
                                
                                if isEditing {
                                    TextField("Tu correo", text: $userEmail)
                                        .keyboardType(.emailAddress)
                                        .textInputAutocapitalization(.never)
                                        .padding()
                                        .background(Color(.systemBackground))
                                        .clipShape(RoundedRectangle(cornerRadius: 12))
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 12)
                                                .stroke(Color(.systemGray4), lineWidth: 1)
                                        )
                                } else {
                                    Text(userEmail)
                                        .padding()
                                        .frame(maxWidth: .infinity, alignment: .leading)
                                        .background(Color(.systemGray6))
                                        .clipShape(RoundedRectangle(cornerRadius: 12))
                                }
                            }
                        }
                        .padding(.horizontal)
                    }
                }
                .padding(.vertical, 24)
                
                // Estadísticas
                VStack(spacing: 20) {
                    Text("Mis Estadísticas")
                        .font(.headline)
                        .foregroundStyle(.primary)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.horizontal)
                    
                    LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 2), spacing: 16) {
                        StatCard(
                            value: "1,200",
                            label: "Puntos",
                            icon: "star.fill",
                            color: .orange
                        )
                        
                        StatCard(
                            value: "15",
                            label: "Duchas registradas",
                            icon: "shower.fill",
                            color: .cyan
                        )
                        
                        StatCard(
                            value: "37L",
                            label: "Consumo hoy",
                            icon: "drop.fill",
                            color: .blue
                        )
                        
                        StatCard(
                            value: "7",
                            label: "Días seguidos",
                            icon: "flame.fill",
                            color: .red
                        )
                    }
                    .padding(.horizontal)
                }
                .padding(.vertical, 24)
                .background(Color(.systemGray6))
            }
        }
        .background(Color(.systemBackground))
        .navigationTitle("Mi Perfil")
        .navigationBarTitleDisplayMode(.inline)
        .sheet(isPresented: $showingAvatarSelector) {
            AvatarSelectorView(selectedAvatar: $selectedAvatar, isPresented: $showingAvatarSelector)
        }
        .photosPicker(isPresented: $showingImagePicker, selection: $selectedItem, matching: .images)
        .onChange(of: selectedItem) { newItem in
            Task {
                if let data = try? await newItem?.loadTransferable(type: Data.self) {
                    selectedImageData = data
                    selectedAvatar = "" // Limpiar avatar si se selecciona imagen
                }
            }
        }
    }
    
    private func saveProfile() {
        // Aquí guardarías la información del perfil
        print("Perfil guardado: \(userName), \(userEmail)")
        
        // Feedback visual
        let generator = UINotificationFeedbackGenerator()
        generator.notificationOccurred(.success)
    }
}

// MARK: - Selector de Avatares
struct AvatarSelectorView: View {
    @Binding var selectedAvatar: String
    @Binding var isPresented: Bool
    
    let columns = [
        GridItem(.flexible()),
        GridItem(.flexible()),
        GridItem(.flexible())
    ]
    
    var body: some View {
        NavigationView {
            ScrollView {
                LazyVGrid(columns: columns, spacing: 20) {
                    ForEach(avataresPredefinidos, id: \.self) { avatar in
                        Button {
                            selectedAvatar = avatar
                            isPresented = false
                        } label: {
                            Image(systemName: avatar)
                                .font(.system(size: 40))
                                .foregroundColor(.white)
                                .frame(width: 80, height: 80)
                                .background(
                                    LinearGradient(
                                        colors: [.blue, .cyan],
                                        startPoint: .topLeading,
                                        endPoint: .bottomTrailing
                                    )
                                )
                                .clipShape(Circle())
                                .overlay(
                                    Circle()
                                        .stroke(selectedAvatar == avatar ? Color.blue : Color.clear, lineWidth: 3)
                                )
                                .scaleEffect(selectedAvatar == avatar ? 1.1 : 1.0)
                        }
                    }
                }
                .padding()
            }
            .navigationTitle("Elige un Avatar")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Listo") {
                        isPresented = false
                    }
                }
            }
        }
    }
}

#Preview {
    NavigationStack {
        PerfilView()
    }
}

//
//  app2App.swift
//  app2
//
//  Created by Daniel  Ricaño on 27/10/25.
//

import SwiftUI

@main
struct app2App: App {
    // 1. Creamos una instancia de nuestro almacén de datos
    // @StateObject asegura que viva mientras la app esté viva
    @StateObject private var consumoStore = ConsumoStore()

    var body: some Scene {
        WindowGroup {
            ContentView()
                // 2. Inyectamos el almacén en el entorno de la app
                // Ahora cualquier vista descendiente puede usar @EnvironmentObject
                .environmentObject(consumoStore)
        }
    }
}

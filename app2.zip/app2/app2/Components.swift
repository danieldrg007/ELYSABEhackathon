//
//  Components.swift
//  app2
//

import SwiftUI

// Componente StatCard para reutilizar en toda la app
struct StatCard: View {
    let value: String
    let label: String
    let icon: String
    let color: Color
    
    var body: some View {
        VStack(spacing: 12) {
            Image(systemName: icon)
                .font(.title3)
                .foregroundColor(color)
            
            VStack(spacing: 4) {
                Text(value)
                    .font(.title2)
                    .fontWeight(.bold)
                    .foregroundStyle(.primary)
                Text(label)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }
        }
        .frame(maxWidth: .infinity)
        .padding()
        .background(Color(.systemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .shadow(color: .black.opacity(0.05), radius: 4, x: 0, y: 2)
    }
}

// Lista de avatares predefinidos para reutilizar
let avataresPredefinidos = [
    "drop.fill", "leaf.fill", "flame.fill", "star.fill", "heart.fill",
    "cloud.fill", "sun.max.fill", "moon.fill", "sparkles", "bolt.fill",
    "tree.fill", "fish.fill", "pawprint.fill", "globe", "water.waves",
    "snowflake", "wind", "hurricane", "thermometer.sun", "umbrella.fill"
]

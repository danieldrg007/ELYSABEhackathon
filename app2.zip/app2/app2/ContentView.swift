//
//  ContentView.swift
//  app2
//
//  Created by Daniel  Ricaño on 27/10/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            InicioView()
                .tabItem {
                    Label("Inicio", systemImage: "house.fill") // Casa para inicio
                }

            Actividades()
                .tabItem {
                    Label("Actividades", systemImage: "checklist") // Lista para actividades
                }

            // Usamos tu nuevo archivo PantallaDosView
            // y corrijo el typo de "Sugerenicas"
            PantallaDosView()
                .tabItem {
                    Label("Chat Ely", systemImage: "message.fill") // Burbuja de mensaje para chat
                }

            JuegoView()
                .tabItem {
                    Label("Juego", systemImage: "gamecontroller.fill") // Control de videojuego para juego
                }
        }
    }
}

#Preview {
    ContentView()
}

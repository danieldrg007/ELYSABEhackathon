//
//  ConsumoStore.swift
//  app2
//

import Foundation
import SwiftUI
import Combine  // 👈 AÑADIR ESTA IMPORTACIÓN

struct RegistroConsumo: Identifiable, Codable {
    let id = UUID()
    let litros: Double
    let tipo: String
    let fecha: Date
    let timestamp: Date
    
    init(litros: Double, tipo: String, fecha: Date = Date()) {
        self.litros = litros
        self.tipo = tipo
        self.fecha = fecha
        self.timestamp = Date()
    }
}

struct ConsumoDiario: Identifiable {
    let id = UUID()
    let fecha: Date
    let totalLitros: Double
    let registros: [RegistroConsumo]
}

@MainActor
class ConsumoStore: ObservableObject {  // 👈 YA ESTÁ BIEN COMO ObservableObject
    @Published var registros: [RegistroConsumo] = [] {
        didSet {
            saveRegistros()
        }
    }
    
    private let key = "registrosConsumo"
    
    init() {
        loadRegistros()
    }
    
    func agregarRegistro(litros: Double, tipo: String) {
        let nuevoRegistro = RegistroConsumo(litros: litros, tipo: tipo)
        registros.append(nuevoRegistro)
    }
    
    func consumosPorDia() -> [ConsumoDiario] {
        let grouped = Dictionary(grouping: registros) { registro in
            Calendar.current.startOfDay(for: registro.fecha)
        }
        
        return grouped.map { fecha, registros in
            let total = registros.reduce(0) { $0 + $1.litros }
            return ConsumoDiario(fecha: fecha, totalLitros: total, registros: registros)
        }.sorted { $0.fecha > $1.fecha }
    }
    
    func totalHoy() -> Double {
        let hoy = Calendar.current.startOfDay(for: Date())
        return registros
            .filter { Calendar.current.startOfDay(for: $0.fecha) == hoy }
            .reduce(0) { $0 + $1.litros }
    }
    
    func promedioDiario() -> Double {
        let consumos = consumosPorDia()
        guard !consumos.isEmpty else { return 0 }
        let total = consumos.reduce(0) { $0 + $1.totalLitros }
        return total / Double(consumos.count)
    }
    
    private func saveRegistros() {
        if let encoded = try? JSONEncoder().encode(registros) {
            UserDefaults.standard.set(encoded, forKey: key)
        }
    }
    
    private func loadRegistros() {
        if let data = UserDefaults.standard.data(forKey: key),
           let decoded = try? JSONDecoder().decode([RegistroConsumo].self, from: data) {
            registros = decoded
        }
    }
}

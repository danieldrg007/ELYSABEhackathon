//
//  Actividades.swift
//  app2
//
//  Mejorada: Daniel Ricaño, 27/10/25
//

import SwiftUI
import Combine

// MARK: - Vista Principal de Actividades
struct Actividades: View {
    var body: some View {
        NavigationStack {
            VStack(spacing: 24) {
                
                // Botones de categorías
                LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 2), spacing: 16) {
                    NavigationLink {
                        BanioDetailView()
                    } label: {
                        categoriaButton(titulo: "Baño", systemImage: "shower", color: .blue)
                    }

                    NavigationLink {
                        LavadoDetailView()
                    } label: {
                        categoriaButton(titulo: "Lavado", systemImage: "washer", color: .green)
                    }

                    NavigationLink {
                        CocinaDetailView()
                    } label: {
                        categoriaButton(titulo: "Cocina", systemImage: "fork.knife", color: .orange)
                    }

                    NavigationLink {
                        OtrosDetailView()
                    } label: {
                        categoriaButton(titulo: "Otros", systemImage: "ellipsis.circle", color: .purple)
                    }
                }
                .padding(.top)
                
                Spacer()
            }
            .padding()
            .navigationTitle("Actividades")
        }
    }
    
    @ViewBuilder
    private func categoriaButton(titulo: String, systemImage: String, color: Color) -> some View {
        VStack(spacing: 12) {
            Image(systemName: systemImage)
                .font(.system(size: 32, weight: .semibold))
                .foregroundStyle(color)
                .frame(width: 70, height: 70)
                .background(color.opacity(0.15))
                .clipShape(RoundedRectangle(cornerRadius: 16))
            
            Text(titulo)
                .font(.headline)
                .foregroundStyle(.primary)
        }
        .frame(maxWidth: .infinity)
        .padding(16)
        .background(.regularMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 20))
        .shadow(color: .black.opacity(0.05), radius: 5, x: 0, y: 2)
    }
}

// MARK: - Modal de Confirmación
struct ConfirmacionModal: View {
    let litros: Double
    let tipo: String
    @Binding var isPresented: Bool
    
    var body: some View {
        ZStack {
            // Fondo semitransparente
            Color.black.opacity(0.4)
                .ignoresSafeArea()
            
            // Contenido del modal
            VStack(spacing: 20) {
                HStack {
                    Spacer()
                    Button(action: {
                        isPresented = false
                    }) {
                        Image(systemName: "xmark.circle.fill")
                            .font(.title2)
                            .foregroundColor(.gray)
                    }
                }
                
                Image(systemName: "checkmark.circle.fill")
                    .font(.system(size: 60))
                    .foregroundColor(.green)
                
                Text("¡Registro Exitoso!")
                    .font(.title2)
                    .fontWeight(.bold)
                    .foregroundColor(.primary)
                
                Text("Has registrado **\(String(format: "%.1f", litros)) litros** para **\(tipo)**")
                    .font(.body)
                    .multilineTextAlignment(.center)
                    .foregroundColor(.secondary)
                
                Button("Aceptar") {
                    isPresented = false
                }
                .buttonStyle(.borderedProminent)
                .tint(.blue)
                .padding(.top, 10)
            }
            .padding(25)
            .background(Color(.systemBackground))
            .cornerRadius(20)
            .shadow(radius: 10)
            .padding(.horizontal, 40)
        }
    }
}

// MARK: - Vista Detalle Baño
struct BanioDetailView: View {
    var body: some View {
        List {
            NavigationLink {
                DuchaTimerView()
            } label: {
                SeccionActividadRow(titulo: "Ducha", systemImage: "shower", color: .blue)
            }
            
            NavigationLink {
                WCTimerView(tipo: "WC con caja de descarga", caudal: 0.15, systemImage: "toilet")
            } label: {
                SeccionActividadRow(titulo: "WC caja descarga", systemImage: "toilet", color: .blue)
            }
            
            NavigationLink {
                WCTimerView(tipo: "WC con fluxómetro", caudal: 1.90, systemImage: "toilet.fill")
            } label: {
                SeccionActividadRow(titulo: "WC fluxómetro", systemImage: "toilet.fill", color: .blue)
            }
            
            NavigationLink {
                ManualInputView(tipo: "Lavabo", caudal: 0.20, systemImage: "hand.wave")
            } label: {
                SeccionActividadRow(titulo: "Lavabo", systemImage: "hand.wave", color: .blue)
            }
            
            NavigationLink {
                ManualInputView(tipo: "Bidet", caudal: 0.10, systemImage: "drop")
            } label: {
                SeccionActividadRow(titulo: "Bidet", systemImage: "drop", color: .blue)
            }
            
            NavigationLink {
                ManualInputView(tipo: "Tina de baño", caudal: 0.30, systemImage: "bathtub")
            } label: {
                SeccionActividadRow(titulo: "Tina de baño", systemImage: "bathtub", color: .blue)
            }
        }
        .listStyle(.insetGrouped)
        .navigationTitle("Baño")
    }
}

// MARK: - Vista Detalle Lavado
struct LavadoDetailView: View {
    var body: some View {
        List {
            NavigationLink {
                LavadoraView()
            } label: {
                SeccionActividadRow(titulo: "Lavadora de ropa", systemImage: "washer", color: .green)
            }
            
            NavigationLink {
                LavadoManoView()
            } label: {
                SeccionActividadRow(titulo: "Lavado a mano", systemImage: "hand.raised.fill", color: .green)
            }
            
            NavigationLink {
                ManualInputView(tipo: "Lavavajillas", caudal: 0.30, systemImage: "dishwasher")
            } label: {
                SeccionActividadRow(titulo: "Lavavajillas", systemImage: "dishwasher", color: .green)
            }
        }
        .listStyle(.insetGrouped)
        .navigationTitle("Lavado")
    }
}

// MARK: - Vista Detalle Cocina
struct CocinaDetailView: View {
    var body: some View {
        List {
            NavigationLink {
                ManualInputView(tipo: "Tarja de cocina", caudal: 0.25, systemImage: "sink")
            } label: {
                SeccionActividadRow(titulo: "Tarja de cocina", systemImage: "sink", color: .orange)
            }
            
            NavigationLink {
                ManualInputView(tipo: "Lavado de trastes", caudal: 0.25, systemImage: "fork.knife")
            } label: {
                SeccionActividadRow(titulo: "Lavado de trastes", systemImage: "fork.knife", color: .orange)
            }
            
            NavigationLink {
                ManualInputView(tipo: "Bebedero", caudal: 0.05, systemImage: "drop.circle")
            } label: {
                SeccionActividadRow(titulo: "Bebedero", systemImage: "drop.circle", color: .orange)
            }
        }
        .listStyle(.insetGrouped)
        .navigationTitle("Cocina")
    }
}

// MARK: - Vista Detalle Otros
struct OtrosDetailView: View {
    var body: some View {
        List {
            NavigationLink {
                ManualInputView(tipo: "Mingitorio auto aspirante", caudal: 0.50, systemImage: "restroom")
            } label: {
                SeccionActividadRow(titulo: "Mingitorio auto aspirante", systemImage: "restroom", color: .purple)
            }
            
            NavigationLink {
                ManualInputView(tipo: "Mingitorio descarga continua", caudal: 0.15, systemImage: "restroom.fill")
            } label: {
                SeccionActividadRow(titulo: "Mingitorio descarga continua", systemImage: "restroom.fill", color: .purple)
            }
            
            NavigationLink {
                ManualInputView(tipo: "Riego de plantas", caudal: 0.10, systemImage: "leaf")
            } label: {
                SeccionActividadRow(titulo: "Riego de plantas", systemImage: "leaf", color: .purple)
            }
            
            NavigationLink {
                ManualInputView(tipo: "Limpieza general", caudal: 0.20, systemImage: "sparkles")
            } label: {
                SeccionActividadRow(titulo: "Limpieza general", systemImage: "sparkles", color: .purple)
            }
        }
        .listStyle(.insetGrouped)
        .navigationTitle("Otros")
    }
}

// MARK: - Fila Reutilizable Mejorada
struct SeccionActividadRow: View {
    let titulo: String
    let systemImage: String
    let color: Color

    var body: some View {
        HStack(spacing: 16) {
            ZStack {
                RoundedRectangle(cornerRadius: 12)
                    .fill(color.opacity(0.15))
                    .frame(width: 60, height: 60)
                Image(systemName: systemImage)
                    .font(.system(size: 24, weight: .semibold))
                    .foregroundStyle(color)
            }
            
            Text(titulo)
                .font(.headline)
                .foregroundStyle(.primary)
            
            Spacer()
            
            Image(systemName: "chevron.right")
                .font(.system(size: 14, weight: .medium))
                .foregroundStyle(.tertiary)
        }
        .padding(.vertical, 8)
        .contentShape(Rectangle())
    }
}

// MARK: - Temporizador de Ducha
struct DuchaTimerView: View {
    @EnvironmentObject var consumoStore: ConsumoStore
    @Environment(\.dismiss) private var dismiss
    
    let caudalRegadera: Double = 0.20 // litros por segundo
    
    @State private var isRunning = false
    @State private var startDate: Date?
    @State private var elapsed: TimeInterval = 0
    @State private var showConfirmation = false
    @State private var litrosUsados: Double = 0.0

    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()

    var body: some View {
        ZStack {
            VStack(spacing: 28) {
                ZStack {
                    Circle()
                        .fill(Color.blue.opacity(0.12))
                        .frame(width: 160, height: 160)
                    Image(systemName: "shower")
                        .font(.system(size: 72, weight: .semibold))
                        .foregroundStyle(.blue)
                }
                .padding(.top)

                Text(formattedTime(elapsed))
                    .font(.system(size: 48, weight: .bold, design: .rounded))
                    .monospacedDigit()

                HStack(spacing: 16) {
                    Button(action: start) {
                        Label("Iniciar", systemImage: "play.fill")
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.green)
                    .disabled(isRunning)

                    Button(action: stop) {
                        Label("Detener", systemImage: "stop.fill")
                    }
                    .buttonStyle(.bordered)
                    .tint(.red)
                    .disabled(!isRunning && elapsed == 0)
                }

                Spacer()
            }
            .padding()
            .navigationTitle("Ducha")
            .onReceive(timer) { _ in
                guard isRunning, let startDate else { return }
                elapsed = Date().timeIntervalSince(startDate)
            }
            
            // Modal de confirmación
            if showConfirmation {
                ConfirmacionModal(
                    litros: litrosUsados,
                    tipo: "Ducha",
                    isPresented: $showConfirmation
                )
                .onDisappear {
                    // Cuando se cierra el modal, regresa al menú anterior
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                        dismiss()
                    }
                }
            }
        }
    }

    private func start() {
        elapsed = 0
        startDate = Date()
        isRunning = true
    }

    private func stop() {
        isRunning = false
        litrosUsados = elapsed * caudalRegadera
        consumoStore.agregarRegistro(litros: litrosUsados, tipo: "Ducha")
        
        // Mostrar modal de confirmación
        showConfirmation = true
    }

    private func formattedTime(_ interval: TimeInterval) -> String {
        let total = Int(interval)
        let minutes = total / 60
        let seconds = total % 60
        return String(format: "%02d:%02d", minutes, seconds)
    }
}

// MARK: - Temporizador para WC
struct WCTimerView: View {
    @EnvironmentObject var consumoStore: ConsumoStore
    @Environment(\.dismiss) private var dismiss
    
    let tipo: String
    let caudal: Double
    let systemImage: String
    
    @State private var isRunning = false
    @State private var startDate: Date?
    @State private var elapsed: TimeInterval = 0
    @State private var showConfirmation = false
    @State private var litrosUsados: Double = 0.0

    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()

    var body: some View {
        ZStack {
            VStack(spacing: 28) {
                ZStack {
                    Circle()
                        .fill(Color.blue.opacity(0.12))
                        .frame(width: 160, height: 160)
                    Image(systemName: systemImage)
                        .font(.system(size: 72, weight: .semibold))
                        .foregroundStyle(.blue)
                }
                .padding(.top)

                Text(formattedTime(elapsed))
                    .font(.system(size: 48, weight: .bold, design: .rounded))
                    .monospacedDigit()

                HStack(spacing: 16) {
                    Button(action: start) {
                        Label("Iniciar", systemImage: "play.fill")
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.green)
                    .disabled(isRunning)

                    Button(action: stop) {
                        Label("Detener", systemImage: "stop.fill")
                    }
                    .buttonStyle(.bordered)
                    .tint(.red)
                    .disabled(!isRunning && elapsed == 0)
                }

                Spacer()
            }
            .padding()
            .navigationTitle(tipo)
            .onReceive(timer) { _ in
                guard isRunning, let startDate else { return }
                elapsed = Date().timeIntervalSince(startDate)
            }
            
            // Modal de confirmación
            if showConfirmation {
                ConfirmacionModal(
                    litros: litrosUsados,
                    tipo: tipo,
                    isPresented: $showConfirmation
                )
                .onDisappear {
                    // Cuando se cierra el modal, regresa al menú anterior
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                        dismiss()
                    }
                }
            }
        }
    }

    private func start() {
        elapsed = 0
        startDate = Date()
        isRunning = true
    }

    private func stop() {
        isRunning = false
        litrosUsados = elapsed * caudal
        consumoStore.agregarRegistro(litros: litrosUsados, tipo: tipo)
        
        // Mostrar modal de confirmación
        showConfirmation = true
    }

    private func formattedTime(_ interval: TimeInterval) -> String {
        let total = Int(interval)
        let minutes = total / 60
        let seconds = total % 60
        return String(format: "%02d:%02d", minutes, seconds)
    }
}

// MARK: - Vista Lavadora (Cálculo por tiempo)
struct LavadoraView: View {
    @EnvironmentObject var consumoStore: ConsumoStore
    @Environment(\.dismiss) private var dismiss
    
    // Caudal de la lavadora (L/s) según la tabla proporcionada: 0.30 L/s
    let caudalLavadora: Double = 0.30
    
    @State private var isRunning = false
    @State private var startDate: Date?
    @State private var elapsed: TimeInterval = 0
    @State private var showConfirmation = false
    @State private var litrosUsados: Double = 0.0

    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()

    var body: some View {
        ZStack {
            VStack(spacing: 28) {
                Text("Mide el tiempo que tarda tu lavadora en llenarse")
                    .font(.title3)
                    .multilineTextAlignment(.center)
                
                Image(systemName: "washer.fill")
                    .font(.system(size: 72, weight: .semibold))
                    .foregroundStyle(.green)
                    .padding(.top)

                Text(formattedTime(elapsed))
                    .font(.system(size: 48, weight: .bold, design: .rounded))
                    .monospacedDigit()
                
                HStack(spacing: 16) {
                    Button(action: start) {
                        Label("Iniciar", systemImage: "play.fill")
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.green)
                    .disabled(isRunning)

                    Button(action: stop) {
                        Label("Detener", systemImage: "stop.fill")
                    }
                    .buttonStyle(.bordered)
                    .tint(.red)
                    .disabled(!isRunning && elapsed == 0)
                }
                
                Spacer()
            }
            .padding()
            .navigationTitle("Lavadora de ropa")
            .onReceive(timer) { _ in
                guard isRunning, let startDate else { return }
                elapsed = Date().timeIntervalSince(startDate)
            }
            
            // Modal de confirmación
            if showConfirmation {
                ConfirmacionModal(
                    litros: litrosUsados,
                    tipo: "Lavadora",
                    isPresented: $showConfirmation
                )
                .onDisappear {
                    // Cuando se cierra el modal, regresa al menú anterior
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                        dismiss()
                    }
                }
            }
        }
    }

    private func start() {
        elapsed = 0
        litrosUsados = 0.0
        startDate = Date()
        isRunning = true
    }

    private func stop() {
        isRunning = false
        litrosUsados = elapsed * caudalLavadora
        consumoStore.agregarRegistro(litros: litrosUsados, tipo: "Lavadora")
        
        // Mostrar modal de confirmación
        showConfirmation = true
    }

    private func formattedTime(_ interval: TimeInterval) -> String {
        let total = Int(interval)
        let minutes = total / 60
        let seconds = total % 60
        return String(format: "%02d:%02d", minutes, seconds)
    }
}

// MARK: - Vista Lavado a Mano (Ingreso manual de litros)
struct LavadoManoView: View {
    @EnvironmentObject var consumoStore: ConsumoStore
    @Environment(\.dismiss) private var dismiss
    
    @State private var inputLitros: String = ""
    @State private var showConfirmation = false
    @State private var litrosRegistrados: Double = 0.0
    @FocusState private var isInputActive: Bool
    
    var body: some View {
        ZStack {
            VStack(spacing: 28) {
                Text("Ingresa los litros que estimas haber usado al lavar a mano.")
                    .font(.title3)
                    .multilineTextAlignment(.center)
                
                Image(systemName: "hand.raised.fill")
                    .font(.system(size: 72, weight: .semibold))
                    .foregroundStyle(.green)
                    .padding(.top)
                
                TextField("Litros (ej: 40)", text: $inputLitros)
                    .keyboardType(.decimalPad)
                    .focused($isInputActive)
                    .padding()
                    .background(Color(.systemGray6))
                    .cornerRadius(12)
                    .padding(.horizontal)

                Button("Registrar Consumo") {
                    registerConsumption()
                }
                .buttonStyle(.borderedProminent)
                .tint(.green)
                .disabled(inputLitros.isEmpty)
                
                Spacer()
            }
            .padding()
            .navigationTitle("Lavado a mano")
            .onTapGesture {
                isInputActive = false
            }
            
            // Modal de confirmación
            if showConfirmation {
                ConfirmacionModal(
                    litros: litrosRegistrados,
                    tipo: "Lavado a mano",
                    isPresented: $showConfirmation
                )
                .onDisappear {
                    // Cuando se cierra el modal, regresa al menú anterior
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                        dismiss()
                    }
                }
            }
        }
    }
    
    private func registerConsumption() {
        isInputActive = false
        guard let litros = Double(inputLitros.replacingOccurrences(of: ",", with: ".")) else {
            return
        }
        
        litrosRegistrados = litros
        consumoStore.agregarRegistro(litros: litros, tipo: "Lavado a mano")
        
        // Mostrar modal de confirmación
        showConfirmation = true
        inputLitros = ""
    }
}

// MARK: - Vista para Ingreso Manual (para elementos sin temporizador)
struct ManualInputView: View {
    @EnvironmentObject var consumoStore: ConsumoStore
    @Environment(\.dismiss) private var dismiss
    
    let tipo: String
    let caudal: Double
    let systemImage: String
    
    @State private var inputLitros: String = ""
    @State private var showConfirmation = false
    @State private var litrosRegistrados: Double = 0.0
    @FocusState private var isInputActive: Bool
    
    var body: some View {
        ZStack {
            VStack(spacing: 28) {
                Text("Ingresa los litros usados para \(tipo.lowercased())")
                    .font(.title3)
                    .multilineTextAlignment(.center)
                
                Image(systemName: systemImage)
                    .font(.system(size: 72, weight: .semibold))
                    .foregroundStyle(.blue)
                    .padding(.top)
                
                VStack(alignment: .leading, spacing: 8) {
                    Text("Litros utilizados:")
                        .font(.headline)
                        .foregroundStyle(.secondary)
                    
                    TextField("Ej: 15.5", text: $inputLitros)
                        .keyboardType(.decimalPad)
                        .focused($isInputActive)
                        .padding()
                        .background(Color(.systemGray6))
                        .cornerRadius(12)
                }
                .padding(.horizontal)

                Button("Registrar Consumo") {
                    registerConsumption()
                }
                .buttonStyle(.borderedProminent)
                .tint(.blue)
                .disabled(inputLitros.isEmpty)
                
                Spacer()
            }
            .padding()
            .navigationTitle(tipo)
            .onTapGesture {
                isInputActive = false
            }
            
            // Modal de confirmación
            if showConfirmation {
                ConfirmacionModal(
                    litros: litrosRegistrados,
                    tipo: tipo,
                    isPresented: $showConfirmation
                )
                .onDisappear {
                    // Cuando se cierra el modal, regresa al menú anterior
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                        dismiss()
                    }
                }
            }
        }
    }
    
    private func registerConsumption() {
        isInputActive = false
        guard let litros = Double(inputLitros.replacingOccurrences(of: ",", with: ".")) else {
            return
        }
        
        litrosRegistrados = litros
        consumoStore.agregarRegistro(litros: litros, tipo: tipo)
        
        // Mostrar modal de confirmación
        showConfirmation = true
        inputLitros = ""
    }
}

#Preview {
    NavigationStack {
        Actividades()
            .environmentObject(ConsumoStore())
    }
}

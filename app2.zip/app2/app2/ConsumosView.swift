//
//  ConsumosView.swift
//  app2
//

import SwiftUI
import Charts

struct ConsumosView: View {
    @EnvironmentObject var consumoStore: ConsumoStore
    @Environment(\.dismiss) private var dismiss
    @State private var selectedTimeFrame = 0
    @State private var selectedDay: ConsumoDiario?
    
    let timeFrames = ["7 días", "30 días", "Todo"]
    
    var filteredConsumos: [ConsumoDiario] {
        switch selectedTimeFrame {
        case 0:
            return Array(consumoStore.consumosPorDia().prefix(7))
        case 1:
            return Array(consumoStore.consumosPorDia().prefix(30))
        default:
            return consumoStore.consumosPorDia()
        }
    }
    
    var body: some View {
        // ⚠️ QUITAMOS NavigationStack de aquí - ya viene del InicioView
        ZStack {
            // Fondo degradado
            LinearGradient(
                colors: [.blue.opacity(0.1), .cyan.opacity(0.1)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            
            ScrollView {
                VStack(spacing: 24) {
                    // Header con estadísticas
                    VStack(spacing: 16) {
                        Text("Consumo de Agua")
                            .font(.largeTitle.bold())
                            .foregroundStyle(.blue.gradient)
                        
                        HStack(spacing: 16) {
                            ConsumptionStatCard(
                                title: "Hoy",
                                value: "\(String(format: "%.0f", consumoStore.totalHoy()))L",
                                icon: "drop.fill",
                                color: .blue
                            )
                            
                            ConsumptionStatCard(
                                title: "Promedio",
                                value: "\(String(format: "%.0f", consumoStore.promedioDiario()))L",
                                icon: "chart.line.uptrend.xyaxis",
                                color: .green
                            )
                        }
                    }
                    .padding(.horizontal)
                    
                    // Selector de tiempo
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Período")
                            .font(.headline)
                            .foregroundStyle(.secondary)
                            .padding(.horizontal)
                        
                        Picker("Período", selection: $selectedTimeFrame) {
                            ForEach(0..<timeFrames.count, id: \.self) { index in
                                Text(timeFrames[index]).tag(index)
                            }
                        }
                        .pickerStyle(.segmented)
                        .padding(.horizontal)
                    }
                    
                    // Gráfico de barras
                    VStack(alignment: .leading, spacing: 16) {
                        HStack {
                            Text("Consumo Diario")
                                .font(.title2.bold())
                            Spacer()
                            Text("Litros")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        .padding(.horizontal)
                        
                        if filteredConsumos.isEmpty {
                            EmptyStateView()
                        } else {
                            ChartView(consumos: filteredConsumos, selectedDay: $selectedDay)
                                .frame(height: 200)
                                .padding(.horizontal)
                        }
                    }
                    
                    // Lista de consumos detallados
                    VStack(alignment: .leading, spacing: 16) {
                        HStack {
                            Text("Registros Detallados")
                                .font(.title2.bold())
                            Spacer()
                            
                            if !filteredConsumos.isEmpty {
                                Text("Total: \(String(format: "%.0f", filteredConsumos.reduce(0) { $0 + $1.totalLitros }))L")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                        }
                        .padding(.horizontal)
                        
                        if filteredConsumos.isEmpty {
                            EmptyStateView()
                        } else {
                            LazyVStack(spacing: 12) {
                                ForEach(filteredConsumos) { consumo in
                                    ConsumoDayCard(consumoDiario: consumo, isSelected: selectedDay?.fecha == consumo.fecha)
                                        .onTapGesture {
                                            withAnimation(.spring()) {
                                                selectedDay = selectedDay?.fecha == consumo.fecha ? nil : consumo
                                            }
                                        }
                                }
                            }
                            .padding(.horizontal)
                        }
                    }
                }
                .padding(.vertical)
            }
        }
        .navigationBarTitleDisplayMode(.inline)
        .navigationTitle("Consumos") // 👈 AÑADIMOS EL TÍTULO DE NAVEGACIÓN AQUÍ
        .toolbar {
            // ⚠️ QUITAMOS el botón "Cerrar" - ya viene el botón de regreso automático
        }
    }
}

// ... (el resto del código se mantiene igual - StatCard, ChartView, ConsumoDayCard, EmptyStateView)

struct ConsumptionStatCard: View {
    let title: String
    let value: String
    let icon: String
    let color: Color
    
    var body: some View {
        VStack(spacing: 8) {
            HStack {
                Image(systemName: icon)
                    .font(.title3)
                    .foregroundColor(color)
                Spacer()
            }
            
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text(title)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    Text(value)
                        .font(.title2.bold())
                        .foregroundStyle(.primary)
                }
                Spacer()
            }
        }
        .padding()
        .background(.regularMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .shadow(color: .black.opacity(0.05), radius: 5, x: 0, y: 2)
    }
}

struct ChartView: View {
    let consumos: [ConsumoDiario]
    @Binding var selectedDay: ConsumoDiario?
    
    var body: some View {
        Chart {
            ForEach(consumos.reversed()) { consumo in
                BarMark(
                    x: .value("Día", consumo.fecha, unit: .day),
                    y: .value("Litros", consumo.totalLitros)
                )
                .foregroundStyle(selectedDay?.fecha == consumo.fecha ? Color.blue.gradient : Color.cyan.gradient)
                .cornerRadius(4)
            }
        }
        .chartXAxis {
            AxisMarks(values: .stride(by: .day)) { value in
                if let date = value.as(Date.self) {
                    AxisValueLabel {
                        Text(date, format: .dateTime.day().month(.defaultDigits))
                            .font(.caption2)
                    }
                }
            }
        }
        .chartYAxis {
            AxisMarks { value in
                AxisGridLine()
                AxisValueLabel {
                    if let litros = value.as(Double.self) {
                        Text("\(Int(litros))L")
                            .font(.caption2)
                    }
                }
            }
        }
    }
}

struct ConsumoDayCard: View {
    let consumoDiario: ConsumoDiario
    let isSelected: Bool
    
    private var dateFormatter: DateFormatter {
        let formatter = DateFormatter()
        formatter.dateStyle = .full
        formatter.timeStyle = .none
        formatter.locale = Locale(identifier: "es_ES")
        return formatter
    }
    
    private var shortDateFormatter: DateFormatter {
        let formatter = DateFormatter()
        formatter.dateFormat = "EEEE d 'de' MMMM"
        formatter.locale = Locale(identifier: "es_ES")
        return formatter
    }
    
    var body: some View {
        VStack(spacing: 0) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text(shortDateFormatter.string(from: consumoDiario.fecha).capitalized)
                        .font(.headline)
                    
                    Text("\(consumoDiario.registros.count) registros")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                
                Spacer()
                
                VStack(alignment: .trailing, spacing: 4) {
                    Text("\(String(format: "%.0f", consumoDiario.totalLitros))L")
                        .font(.title3.bold())
                        .foregroundStyle(.blue)
                    
                    Text("Total")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                
                Image(systemName: isSelected ? "chevron.up" : "chevron.down")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            .padding()
            .contentShape(Rectangle())
            
            if isSelected {
                VStack(spacing: 8) {
                    ForEach(consumoDiario.registros.sorted { $0.timestamp > $1.timestamp }) { registro in
                        HStack {
                            Image(systemName: iconForType(registro.tipo))
                                .foregroundStyle(.blue)
                                .frame(width: 24)
                            
                            Text(registro.tipo)
                                .font(.subheadline)
                            
                            Spacer()
                            
                            Text("\(String(format: "%.1f", registro.litros))L")
                                .font(.subheadline.bold())
                                .foregroundStyle(.secondary)
                            
                            Text(registro.timestamp, style: .time)
                                .font(.caption)
                                .foregroundStyle(.tertiary)
                        }
                        .padding(.horizontal)
                    }
                }
                .padding(.vertical, 8)
                .background(Color.blue.opacity(0.05))
            }
        }
        .background(.regularMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .shadow(color: .black.opacity(0.05), radius: 3, x: 0, y: 1)
    }
    
    private func iconForType(_ tipo: String) -> String {
        switch tipo {
        case "Ducha": return "shower"
        case "Lavadora": return "washer"
        case "Lavado a mano": return "hand.raised.fill"
        case "Lavavajillas": return "dishwasher"
        case "WC": return "toilet"
        case "Lavabo": return "hand.wave"
        case "Bidet": return "drop"
        case "Tina de baño": return "bathtub"
        case "Tarja de cocina": return "sink"
        case "Lavado de trastes": return "fork.knife"
        case "Bebedero": return "drop.circle"
        case "Mingitorio": return "restroom"
        case "Riego de plantas": return "leaf"
        case "Limpieza general": return "sparkles"
        default: return "drop"
        }
    }
}

struct EmptyStateView: View {
    var body: some View {
        VStack(spacing: 16) {
            Image(systemName: "chart.bar.doc.horizontal")
                .font(.system(size: 50))
                .foregroundStyle(.secondary)
            
            Text("No hay registros aún")
                .font(.headline)
                .foregroundStyle(.secondary)
            
            Text("Comienza a registrar tu consumo de agua para ver estadísticas aquí")
                .font(.caption)
                .foregroundStyle(.tertiary)
                .multilineTextAlignment(.center)
        }
        .padding()
        .frame(maxWidth: .infinity)
        .background(.regularMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .padding(.horizontal)
    }
}

#Preview {
    NavigationStack { // 👈 SOLO EN EL PREVIEW PONEMOS NavigationStack
        ConsumosView()
            .environmentObject(ConsumoStore())
    }
}

